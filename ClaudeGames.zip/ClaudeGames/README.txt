CLAUDE GAMES — four fully-offline single-file games
Open any .html file in a browser. No internet needed. Progress saves locally.

PulseVault.html    - neon descent arcade: graze hazards, charge your Pulse, unlock stages
CircuitSiege.html  - tower defense: build and upgrade towers, survive 30+ waves
Gridville.html     - city-building sim: roads, power, parks, expansion, autosaves
TurboCourier.html  - top-down driving: package/taxi/rush missions, garage upgrades
